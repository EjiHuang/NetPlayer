﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetPlayer.WinUI.ViewModels
{
    [INotifyPropertyChanged]
    public partial class MainPageViewModel
    {
        [RelayCommand]
        private void Play()
        {
            Debug.WriteLine("AAA");
        }
    }
}
