﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Diagnostics;

namespace NetPlayer.WinUI
{
    [INotifyPropertyChanged]
    internal partial class MainViewModel
    {
        [RelayCommand]
        private void Play()
        {
            Debug.WriteLine("AAA");
        }
    }
}
